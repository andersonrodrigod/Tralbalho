import mouseinfo
mouseinfo.mouseInfo()